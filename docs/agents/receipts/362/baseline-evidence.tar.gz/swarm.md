# Pattern swarm, baseline 26ad847

| Slice | Result | Disposition |
|---|---|---|
| 1: fixture setup and runReview | PASS, cost hypothesis | Repeated isolated setup preserved; trace measures enclosing work. |
| 2: helper hang | PASS, cost hypothesis | Existing helper timeout and death-signal regression preserved. |
| 3: closed proof pairs and full/delta | PASS, cost hypothesis | All proof/failure cases remain independent. |
| 4: synthetic HOME, named PR, slot acquisition | PASS, cost hypothesis | No observed shared queue wait; boundaries retained. |
| 5: scheduler/source/symlink defenses | PASS, cost hypothesis | No sandbox regression weakened or replaced. |
| 6: helper and metadata calls | Confirmed redundant wrapper | Independent verifier confirms extra interpreter layer; red direct-Git test added. |
| 7: proof and scheduler boundary | Unproven historical wait | Local trace settles both isolated scheduler tests; no unrelated scheduler edit. |
| 8: guard and probe | PASS | Refusal, allow, fail-closed, probe hang and hook trust intact. |
| 9: skills and agents | PASS | Interrupted file label does not establish a skills bug; no edits. |
| 10: limits and shared Workflow | Confirmed conditional timeout | Dedicated signal test proves old success-on-timeout outcome; narrow runner replacement. |

Ten partitions completed without a coverage gap. Static work hypotheses were
not promoted to CI root-cause claims. The direct-Git finding was independently
verified; the timeout finding is proved by the dedicated red synthetic test.
