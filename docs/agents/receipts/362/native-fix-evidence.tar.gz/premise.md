Premise rejected: shutdown can safely depend on a fresh process-table read.

Rerunnable census: node --test scripts/codex-check-inspection.test.mjs
The fixture announces readiness, disables only its harness process inspection,
then observes the root, descendant and unrelated control before fallback cleanup.
It distinguishes a cooperative shared group, a detached group, and a shared group
whose leader exits while its descendant ignores TERM. The latter two survive the
old fallback; the unrelated control must survive every case.

Replacement: pin each owned Node process-group identity with a bounded keeper.
A keeper ignores TERM and holds the group's namespace through grace/escalation;
it has its own deadline and is killed with that group. Direct unleased helpers
remain under the runtime's live ChildProcess handles at parent termination.
Use successful inspection for extra attribution, never as a shutdown prerequisite.

Second premise rejected: Node-only group reservations cover every descendant.
The native-shell census in red-native.log shows an unrecorded orphan after its
direct shell exits while inspection is unavailable. The control stays alive.
Replacement: reserve detached native groups before exec and ask their live owner
to signal itself through a control FIFO, so a dead/released group record cannot
signal a recycled numeric identity. Preserve target arguments, streams and env.
